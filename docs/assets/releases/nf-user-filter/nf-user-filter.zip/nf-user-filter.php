<?php
/*
* Plugin Name: Nex Forms User Filter
 * Description: Erweiterung für Nex-Forms. Sobald ein Formular abgeschickt wird, wird in der Datenbank sowie im Cookie ein Eintrag hinterlassen. Blockt erneute Teilnahme für 30 Tage. Siehe Plugin Webseite für Dokumentation.
 * Version: 0.2
 * Author: Alexander Jahn
 * Author URI: https://alxndrjhn.github.io/
 * Plugin URI: https://alxndrjhn.github.io/nfuserfilter/
*/
global $blockedDays;
$blockedDays = 30;

function get_visitor_ip()
{
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        //check ip from internet
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        //to check ip is pass from proxy
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return apply_filters('wpb_get_ip', $ip);
}
function get_visitor_passive_fp()
{
    $headers = array_change_key_case(getallheaders(), CASE_LOWER);
    // print_r($headers);
    $fingerprintStr = '';
    $headerKeys = array('accept', 'accept-encoding', 'accept-language',  'user-agent', 'dnt', 'accept-charset');
    foreach ($headerKeys as &$value) {
        // print_r($value);
        $keys = array_keys($headers);
        if (in_array($value, $keys)) {
            // print_r('includes<br>');
            $idx = array_search($value, $keys);
            $fingerprintStr .= strval($idx);
            $fingerprintStr .= $headers[$value];
        }
    }
    // print_r('<br>');
    // print_r("DEBUG: " . $fingerprintStr);
    $fingerprint = md5($fingerprintStr);
    // print_r($fingerprint);
    return $fingerprint;
}



function nf_wrapper($atts, $content = null, $tag = '')
{
    $a = shortcode_atts(array(
        "alreadysubmitted" => "already submitted",
    ), $atts);

    // cookie
    // print_r($_COOKIE);

    // $passive_fp = get_visitor_passive_fp();

    // get nex form id
    $rgx = '/id="(\d+)"/m';
    preg_match($rgx, $content, $matches);

    $hasParticipated = false;
    if (count($matches) > 0) {
        global $wpdb;
        global $blockedDays;
        $query = 'SELECT COUNT(*) FROM ' . $wpdb->prefix . 'wap_nex_forms_entries_ips WHERE created_at > now() - interval ' . $blockedDays . ' DAY and ip = \'' . get_visitor_ip() . '\' and form_id = ' . $matches[1];
        $hasSubmitted = $wpdb->get_var($wpdb->prepare($query));
        if ($hasSubmitted > 0)
            $hasParticipated = true;

        // check cookie
        $subs = $_COOKIE['submitted_form_' . $matches[1]];
        if ($subs != null) {
            $hasParticipated = true;
        }
    } else
        // if plugin is set incorrectly (no nex form shortcode with id default to show shortcode
        $hasParticipated = false;

    if ($hasParticipated) {
        $Content = "<style>";
        $Content .= "h3.already-participated {";
        $Content .= "color: #000;";
        $Content .= "}";
        $Content .= "</style>";
        $Content .= '<h3 class="already-participated">' . $a['alreadysubmitted'] . '</h3>';
    } else
        $Content =  do_shortcode($content);
    return $Content;
}

function submission_hook()
{
    global $wpdb;
    global $blockedDays;

    $formId = filter_var($_REQUEST['nex_forms_Id'], FILTER_SANITIZE_NUMBER_INT);

    // check if db contains ip
    $query = 'SELECT COUNT(*) FROM ' . $wpdb->prefix . 'wap_nex_forms_entries_ips WHERE created_at > now() - interval ' . $blockedDays . ' DAY and ip = \'' . get_visitor_ip() . '\' and form_id = ' . $formId;
    $hasSubmitted = $wpdb->get_var($wpdb->prepare($query));

    // check cookie
    $subs = $_COOKIE['submitted_form_' . $formId];
    if ($subs != null) {
        $hasSubmitted = 1;
    }

    // add to cookie
    setcookie('submitted_form_' . $formId, "1", time() + 60 * 60 * 24 * $blockedDays, '/');

    // decide to submit or not
    if ($hasSubmitted > 0) {
        // cancel form
        $_POST['email'] = '@qq.com';
    } else {
        // add ip to db
        $wpdb->insert(
            $wpdb->prefix . 'wap_nex_forms_entries_ips',
            array(
                'form_id' => filter_var($_REQUEST['nex_forms_Id'], FILTER_SANITIZE_NUMBER_INT),
                'ip' => get_visitor_ip(),
            )
        );
    }
}

add_shortcode('nf-user-filter', 'nf_wrapper');

add_action('wp_ajax_submit_nex_form', 'submission_hook', 0);
add_action('wp_ajax_nopriv_submit_nex_form', 'submission_hook', 0);

// database installation hook
global $nf_user_filter_version;
$nf_user_filter_version = '1.0';

function nf_user_filter_install_db()
{
    global $wpdb;
    global $nf_user_filter_version;

    $table_name = $wpdb->prefix . 'wap_nex_forms_entries_ips';

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id bigint(255) unsigned auto_increment,
        ip varchar(255) not null,
        form_id bigint(255) unsigned,
        created_at timestamp default current_timestamp,
		PRIMARY KEY  (id)
	) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    add_option('nf_user_filter_version', $nf_user_filter_version);
}

register_activation_hook(__FILE__, 'nf_user_filter_install_db');

// deactivation hook
function nf_user_filter_uninstall_db()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'wap_nex_forms_entries_ips';
    $sql = "DROP TABLE IF EXISTS $table_name;";
    $wpdb->query($sql);
    delete_option('nf_user_filter_version');

    // cron
    wp_unschedule_hook('remove_old_nf_ip_filter_entries_event');
}
register_deactivation_hook(__FILE__, 'nf_user_filter_uninstall_db');

// database cleanup once daily
// wp_unschedule_hook('remove_old_nf_ip_filter_entries_event');
if (!wp_next_scheduled('remove_old_nf_ip_filter_entries_event')) {
    wp_schedule_event(current_time('timestamp'), 'daily', 'remove_old_nf_ip_filter_entries_event');
}
function do_remove_old_nf_ip_filter_entries()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'wap_nex_forms_entries_ips';
    $sql = "DELETE FROM $table_name WHERE created_at < now() - interval 30 DAY;";
    $wpdb->query($sql);
}
add_action('remove_old_nf_ip_filter_entries_event', 'do_remove_old_nf_ip_filter_entries');
